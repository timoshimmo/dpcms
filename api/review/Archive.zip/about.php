﻿<?php
include 'header.php';
?>
			<section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2>About</h2>
							<ol class="breadcrumb greylinks">
								<li> <a href="home">
							Home
						</a> </li>
								<li class="active">About</li>
							</ol>
						</div>
					</div>
				</div>
			</section>
			<section id="about" class="ls section_padding_top_110 columns_padding_30">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-push-6 to_animate" data-animation="fadeInUp" data-delay="600">
							<div class="embed-responsive embed-responsive-3by2"> <a href="https://www.youtube.com/embed/xKxrkht7CpY" class="embed-placeholder">
						<img src="https://i.ibb.co/VJ7zR8Z/DSC-0278.jpg" alt="">
					</a> </div>
						</div>
						<div class="col-md-6 col-md-pull-6 to_animate" data-animation="fadeInRight" data-delay="300">
							<h2 class="section_header color4"> What is DPCMS </h2>
							<p class="section-excerpt grey">Creating A Better Future Together</p>
							<p>Destiny Promoters Cooperative Multipurpose Society (DPCMS) is an affiliate of Destiny Promoters Evangelical Outreach. A social enterprise cooperative dedicated to enhancing the lives of her members and the broader community. We are duly registered with both the Corporate Affairs Commission of Nigeria (CAC) RC: 7168250 and the Lagos State Ministry of Commerce Cooperative Trade and Investment. Our mission is to foster financial stability, improve living standards, and cultivate a sense of community and belonging among our members. </p>
						</div>
					</div>
				</div>
			</section>

			<section class="ls section_padding_top_100 section_padding_bottom_100">
				<div class="container">
					<div class="row">
						<div class="col-xs-12"> <img src="https://i.ibb.co/9Txbgm8/DSC-0346.jpg" alt="" class="alignright">
							<h2 class="section_header topmargin_0">Benefits of Being A Member</h2>
							<p><br>1. Financial Security and Support
								<br>2. Food Incentives.
								<br> 3. Daily/ Weekly/Monthly Contribution And Thrift.
								<br> 4. Access To Our Schools With Subsidized Fees And Convenient Payment Plans.
								<br> 5. Bussiness Capital Financing Support Loan.
								<br> 6. Access To Low - Interest Loan.
								<br> 7. Access To Our Low-Priced Shops <br>
								8. Low - Cost Housing,
								And Lots More.</p>

								<h2 class="section_header topmargin_0">To Be A Member</h2>
							<p>Sign Up With N5,500 Covering:
								<br>1. Two Weeks Contribution/Thrift.
								<br> 2. A Registration Fee Of N2,500.00.
								</p>
							
								<h2 class="section_header topmargin_0">CONTRIBUTION DETAILS:</h2>
					
							<p id="tester">
								<br> 1. Weekly contribution of ₦1,500 for 50 weeks
								<br> 2. Membership referral within 1st to 25th weeks of Registration. 
								<br> 3. Members with 50 weeks matured contribution of N75,000.00 with a Referral shall be paid N150,000.00 with Food Incentives.
								<br> 4. Members with 50 weeks matured contribution of N75,000.00 Without a Referral shall be paid N75,000.00 Contributed amoount Only.
								<br> 5. Weekly Contribution ends at 11:59PM Every Saturday. Late payment attracts a default Penalty payment of  100% of the weekly contribution.
								<br> 6. Termination of Account at any point incurs a cancellation fee of N10,000.00
								<br> 7. All members can fully patronise our Schools, Low- Cost Houses, Shops and other Services at  subsidised fees.
								<br> 8. Members are entitled to Incentives Such as Loans, Discounted Food Items Sales and Bussiness Empowerment after a minimum of 50 weeks contribution. 
								<br> 9. Members are allowed to operate multiple accounts.
								


							</p>
							<h2 class="section_header topmargin_0">TYPES OF THRIFT/ACCOUNT:</h2>


						
							<ul class="list2 checklist">
								<li>Daily Savers (Daily Thrift)</li>
								<li>Trimester Thrift (Three Months (13 Weeks) Plan With Ten Referrals From 1st - 4th Week Of Registration).</li>
								<li>Semestrial Thrift.

									(Six Months (25 Weeks) Plan With Five Referrals From 1st - 7th Week Of Registration).</li>
								<li>Premium Thrift 

									(Twelve Months (50 Weeks) Plan With One Referral From 1st - 30th Week Of Registration)</li>
								<li>Wealthbuilders Account (For Core Cooperative Members)</li>
							</ul>
							<p>CONTACT US: <br>
								For More Information, Visit Us At:
								Office: 55, Demurin Road, Elebiju Bus-Stop, Beside NEPA Office, Ketu Lagos. 
								<br>Working Hours: Mondays - Saturdays. (9:00AM - 5:00PM)
								<br>Call/Whatsapp: 0818 4212487, 09060387323</p>
							<p>.</p>
						</div>
					</div>
				</div>
			</section>
<?php
include 'footer.php';
?>