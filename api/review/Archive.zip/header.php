<!DOCTYPE html>
<html class="no-js">
<head>
	<title>DPCMS</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/fonts.css">
	<link rel="stylesheet" href="css/main.css" class="color-switcher-link">
	<link rel="stylesheet" href="css/shop.css" class="color-switcher-link">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>
</head>

<body>
	
	<div class="preloader">
		<div class="preloader_image"></div>
	</div>
	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal"> <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">
			<i class="rt-icon2-cross2"></i>
		</span>
	</button>
		<div class="widget widget_search">
			<form method="get" class="searchform search-form form-inline" action="./">
				<div class="form-group bottommargin_0"> <input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input"> </div> <button type="submit" class="theme_button no_bg_button">Search</button> </form>
		</div>
	</div>
	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls with_padding">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--
		<ul class="list-unstyled">
			<li>Message To User</li>
		</ul>
		-->
		</div>
	</div>
	<!-- eof .modal -->
	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">
			<!-- template sections -->
			<section class="page_topline ds table_section table_section_lg section_padding_top_15 section_padding_bottom_15 columns_margin_0">
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-6 text-center text-lg-left hidden-xs">
							<div class="inline-content big-spacing">
								<div class="page_social"> <a class="social-icon socicon-facebook" href="https://www.facebook.com/destiny.promoters.cooperative.multipurpo.2024?mibextid=ZbWKwL" title="Facebook"></a> <a class="social-icon socicon-twitter" href="twitter.com/destinypromoterscooperative;" title="Twitter"></a> <a class="social-icon socicon-google" href="javascript:void();" title="Google Plus"></a> <a class="social-icon socicon-linkedin" href="javascript:void();" title="Linkedin"></a> <a class="social-icon socicon-youtube" href="javascript:void();" title="Youtube"></a> </div> <span class="xs-block">
						
						<i class="fa fa-envelope highlight3 rightpadding_5" aria-hidden="true"></i>
							<a href="mailto:support@destinypromoterscooperative.com">support@destinypromoterscooperative.com</a>
					</span> </div>
						</div>
						<div class="col-lg-6 text-center text-lg-right">
							<div id="topline-animation-wrap">
								<div id="topline-hide" class="inline-content big-spacing"> <span class="hidden-xs">
							<i class="fa fa-map-marker highlight3 rightpadding_5" aria-hidden="true"></i>
							55, Demurin Road, Opposite Elebiju Bustop, Beside Ikeja Electrics.  Ketu, Lagos State
						</span> <span class="greylinks hidden-xs">
							
						</span>

								</div>

							</div>
						</div>
					</div>
				</div>
			</section>
			<header class="page_header header_white toggler_xs_right columns_margin_0">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-12 display_table">
							<div class="header_left_logo display_table_cell"> <a href="index" class="logo logo_with_text">
                        <img src="https://i.ibb.co/2NJ7pCS/dpcms-logo.png" alt="">
                        <span class="logo_text">
                            DPCMS
                            <small class="highlight4">Destiny Promoters Cooperative</small>
                        </span>
                    </a> </div>
							<div class="header_mainmenu display_table_cell text-center">
								<!-- main nav start -->
								<nav class="mainmenu_wrapper">
									<ul class="mainmenu nav sf-menu">
										<li class="active"> <a href="index">Home</a>
										</li>

										<li> <a href="about">About</a> </li>
										
										<li> <a href="contact">Contact</a> </li>

										

						
										<!-- eof shop -->
										<!-- contacts -->
								
										<!-- eof contacts -->
									</ul>
								</nav>
								<!-- eof main nav -->
								<!-- header toggler --><span class="toggle_menu"><span></span></span>
							</div>
							<div class="header_right_buttons display_table_cell text-right hidden-xs"> <a href="javascript:void();" class="theme_button color2 margin_0" onclick="alert('Inprogress \n\n Coming soon');">Register/Login</a> </div>
						</div>
					</div>
				</div>
			</header>