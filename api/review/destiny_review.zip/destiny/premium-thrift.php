<?php
include 'header.php';
?>
			<section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2>Premium Thrift</h2>
							<ol class="breadcrumb greylinks">
								<li> <a href="home">
							Home
						</a> </li>
								<li class="active">Premium Thrift</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ls section_padding_top_100 section_padding_bottom_100">
				<div class="container">
					<div class="row">
						<div class="col-xs-12"> 
							
		
							<h2 class="section_header topmargin_0" style="text-transform: uppercase;">Premium Thrift:</h2>

							<p>The Premium Thrift is our Fifty(50) weeks empowernent savings program  that encourages individuals to contribute a fixed amount of N1,500.00 at weekly intervals for a duration of fifty(50) weeks.  
<br><br>
Our Premium Thrift encourages individuals to develop a disciplined savings habit that helps them save to achieve Long-term goals, such as education, retirement and other major expenses. 
</p>

<p><b>How Our Premium Thrift Operates?</b>

<ol>
	<li>Join the Premium Thrift Empowerment program by registering with N3,000.00 and agreeing to the terms and conditions.</li>

	<li>After Registration, Contribute N1,500.00 weekly for a fixed period of 50 weeks.. </li>

	<li>Your Contribution for the fifty(50) weeks shall amount to N75,000.00.  </li>

	<li>Upon contribution of 50 weeks Thrift amount (N75,000.00) within 50 weeks of membership and a referal of at least One(1) new active member as your downline within the 1st to 25th week of being a member;</li>

	<li>Your Thrift account will be qualified for the empowerment of N150,000.00 and Foodstuffs/Household Items Incentives to support and enhance your Livelihood. </li>

	<li>However, if you are unable to refer a new member as your downline, you shall be empowered with your contributed amount of N75,000.00  and food product Incentive after fifty(50) weeks
</li>
</ol>

</p>
							<p><button class="theme_button color2 margin_0">Click to Register</button></p>
						</div>
					</div>
				</div>
			</section>
<?php
include 'footer.php';
?>