<?php
include 'header.php';
?>
			<section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2>Daily Savers Thrift</h2>
							<ol class="breadcrumb greylinks">
								<li> <a href="home">
							Home
						</a> </li>
								<li class="active">Daily Savers Thrift</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ls section_padding_top_100 section_padding_bottom_100">
				<div class="container">
					<div class="row">
						<div class="col-xs-12"> 
							
		
							<h2 class="section_header topmargin_0" style="text-transform: uppercase;">Daily Savers Thrift:</h2>

							<p>Daily Savers Thrift is our daily savings empowerment  program that encourages individuals to save a fixed amount of money daily. It's a simple, yet effective way to build savings habits making it easier to save money over time and achieving financial goals. </p>

<p><b>How Our Daily Saving Thrift Work?</b>

<ol>
	<li>Empowerment Registration of N1,500.00 is required.</li>

	<li>Determine how much you can afford to save each day. </li>

	<li>Deposit your daily savings into a designated bank account that will be given to you after registration. </li>

	<li>Our Daily Savers Thrift matures at Thirty-One (31) days. Afterwards, members are paid Thirty (30) days Accrued Contributed amount and Foodstuffs or Household Incentives upon regular and continuous payments. </li>

	<li>The remaining one day is used as clearance and administrative contribution. </li>

	<li>For Twelve(12) Months Fixed Daily Savings, Members are Empowered with the Accrued Contributed Amount, Thirty (30) percentage of the total sum and foodstuffs/household incentives.</li>
</ol>

<b>Tips for Successful Daily Saving Thrift</b>

<ol> <li><b>Start Small</b>: Begin with a small daily savings amount and gradually increase it over time.</li>

	<li><b>Make it Automatic</b>: Set up automatic transfers from your personal account to your thrift saving account to make saving easier and less prone to being neglected or defaulted. </li>

	<li><b>Avoid Unnecessary Spending</b>: Avoid Unnecessary spending by keeping your savings account separate from your everyday spending account.</li>

	<li><b>Review and Adjust</b>: Regularly review your savings progress and adjust your daily savings amount as needed to stay on track with your financial capacity and goals.</li></ol>
</p>
							<p><button class="theme_button color2 margin_0">Click to Register</button></p>
						</div>
					</div>
				</div>
			</section>
<?php
include 'footer.php';
?>