<?php
header("Location:home");
?>