<?php
include 'header.php';
?>
			<section class="page_breadcrumbs ds background_cover section_padding_top_65 section_padding_bottom_65">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<h2>Trimestral Thrift</h2>
							<ol class="breadcrumb greylinks">
								<li> <a href="home">
							Home
						</a> </li>
								<li class="active">Trimestral Thrift</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ls section_padding_top_100 section_padding_bottom_100">
				<div class="container">
					<div class="row">
						<div class="col-xs-12"> 
							
		
							<h2 class="section_header topmargin_0" style="text-transform: uppercase;">Trimestral Thrift:</h2>

							<p>The Trimestral Thrift is our Three months (13weeks)  empowernent savings program that encourages individuals to contribute a fixed amount of N1,500.00 at weekly intervals for a duration of three months (13weeks). 
<br><br>
Our Trimestral Thrift encourages individuals to develop a disciplined savings habit that helps them save to achieve short-term goals, such as vacations, holidays, or unexpected expenses.
</p>

<p><b>How Our Trimestral Thrift Operates?</b>

<ol>
	<li>Join the Trimestral Thrift Empowerment program by registering with N3,000.00 and agreeing to the terms and conditions.</li>

	<li>After Registration, Contribute N1,500.00 weekly for a fixed period of 13 weeks. </li>

	<li>Your Contribution for the Thirteen (13) weeks shall amount to N19,500.00.</li>

	<li>To automatically make your Thrift matured for empowerment after 13 weeks, you will be required to pay the make-up of 37 weeks thrift that amounts to N55,500.00 making your total contribution of N75,000.00 which is the value of the Fifty(50) weeks matured Thrift.</li>

	<li>Upon contribution of 50 weeks Thrift amount (N75,000.00) within the 13 weeks of membership and a referal of at least Ten(10) new active members as your downlines within the 1st to 4th week of being a member. </li>

	<li>Your Thrift account will be qualified for the empowerment of N150,000.00 and Foodstuffs/Household Items Incentives to support and enhance your Livelihood.</li>

	<li>However, if you are able to refer at least One(1) new active member under you within the 1st to 25th week of being a member;  you will also be empowered with N150,000.00 and Foodstuffs/Household Items Incentives to support and enhance your Livelihood but this will be after 50 weeks duration. </li>

	<li>Upon no referral of new members, you shall be empowered with your contributed amount of N75,000.00  and food product Incentive after 50weeks</li>
</ol>

</p>
							<p><button class="theme_button color2 margin_0">Click to Register</button></p>
						</div>
					</div>
				</div>
			</section>
<?php
include 'footer.php';
?>